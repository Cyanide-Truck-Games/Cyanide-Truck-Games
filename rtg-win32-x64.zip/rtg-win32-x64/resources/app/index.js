const electron = require('electron');
const {Menu} = require('electron');

const {app, BrowserWindow} = electron;

let mainWindow;

app.on('ready', function() {
    mainWindow = new BrowserWindow({
        width: 1280,
        height: 720
    });
    mainWindow.loadFile('mainWindow.html');

    mainWindow.on('closed', function() {
        app.quit();
    });

    mainMenu = Menu.buildFromTemplate(mainWindowTemplate);
    Menu.setApplicationMenu(mainMenu);
});

const mainWindowTemplate = [
    {
        label: 'File',
        submenu:[
            {
                role: 'togglefullscreen',
                accelerator: 'CmdOrCtrl+F'
            },

            {
                label: 'Quit',
                accelerator: 'CmdOrCtrl+Q',
                click() {
                    app.quit();
                }
            }
        ]
    },
    {
        label: 'Developer Tools',
        submenu:[
            {
                role: 'reload'
            }
        ]
    },
]