var scene, camera, renderer;

scene = new THREE.Scene();
scene.background = new THREE.Color(0x99ccff);

camera = new THREE.PerspectiveCamera(90, window.innerWidth / window.innerHeight, 0.1, 1000);
renderer = new THREE.WebGLRenderer();

var keyboard = {};
var player = {height: 1.8, speed: 1};

let controls = new THREE.PointerLockControls(camera, renderer.domElement);

isLocked = true;

function init() {
    terrain = new THREE.Mesh(
        new THREE.PlaneBufferGeometry(2000, 2000, 256, 256),
        new THREE.MeshLambertMaterial({color: 0x009900})
    );

    var perlin = new SimplexNoise();
    var peak = 105;
    var smoothing = 400;
    var vertices = terrain.geometry.attributes.position.array;

    for (var i = 0; i <= vertices.length; i += 3) {
        vertices[i + 2] = peak * perlin.noise(
            (terrain.position.x + vertices[i]) / smoothing, 
            (terrain.position.z + vertices[i + 1]) / smoothing
        );
    }

    terrain.geometry.attributes.position.needsUpdate = true;
    terrain.geometry.computeVertexNormals();

    terrain.rotation.x -= Math.PI / 2;
    terrain.position.y -= 65;

    terrain.castShadow = true;
    terrain.receiveShadow = true;

    scene.add(terrain);

    water = new THREE.Mesh(
        new THREE.PlaneBufferGeometry(2000, 2000, 256, 256),
        new THREE.MeshPhongMaterial({color: 0x0080ff, opacity: 0.5, transparent: true})
    )

    water.rotation.x -= Math.PI / 2;
    water.position.y -= 115;

    scene.add(water);

    ambientLight = new THREE.AmbientLight(0xffffff, 0.2);
    scene.add(ambientLight);

    light = new THREE.DirectionalLight(0xffffff, 0.8);
    light.position.set(0, 6, 0);
    light.castShadow = true;
    light.shadow.camera.near = 0.1;
    light.shadow.camera.far = 25;
    scene.add(light);

    window.addEventListener('resize', onResize);

    renderer.setSize(window.innerWidth, window.innerHeight);

    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.BasicShadowMap;

    document.body.appendChild(renderer.domElement);

    animate();
}

function animate() {
    requestAnimationFrame(animate);

    if (keyboard[27]) {
        isLocked = false;
    }

    if (keyboard[87]){
		controls.moveForward(player.speed);
	}
	if (keyboard[83]){
		controls.moveForward(-player.speed);
	}
	if (keyboard[68]){
		controls.moveRight(player.speed);
    }
    if (keyboard[65]){
		controls.moveRight(-player.speed);
    }
    
    if (keyboard[67]) {
        player.speed = 3;
    }
    else {
        player.speed = 1;
    }

    if (isLocked) {
        controls.lock();
    }
    else {
        controls.unlock();
    }

    renderer.render(scene, camera);
}

window.addEventListener('keydown', function(event) {
    keyboard[event.keyCode] = true;
});

window.addEventListener('keyup', function(event) {
    keyboard[event.keyCode] = false;
});

function onWindowClick() {
    isLocked = true;
}

function onResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();

    renderer.setSize(window.innerWidth, window.innerHeight);
}

window.onload = init;