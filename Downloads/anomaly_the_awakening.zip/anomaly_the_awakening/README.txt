####################################################
# Thank you for downloading ANOMALY: THE AWAKENING #
####################################################

############################################################################################
# DESCRIPTION:                                                                             #
# -------------------------------------------------------------------------------------    #
# Anomaly: The Awakening is a sci-fi horror game created by Cyanide Truck Game             #
# inspired by the events in r/OperationArchive (https://www.reddit.com/r/OperationArchive) #
############################################################################################

#################################################################################################################
# FAQ                                                                                                           #
# -----------------------------                                                                                 #
# What engine is this made in?                                                                                  #
# It is made in a modified version of javidx9's Console Raycaster (https://www.youtube.com/watch?v=xW8skO7MFYw) #
#                                                                                                               #
# What language was this written in?                                                                            #
# It was written in Windows C++                                                                                 #
#################################################################################################################